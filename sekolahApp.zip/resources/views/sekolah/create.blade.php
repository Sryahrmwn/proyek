@extends('layouts.app')

@section('content')
    <div class="py-8">
        <div class="max-w-4xl mx-auto sm:px-6 lg:px-8">
            <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
                {{ __('Tambah Data Sekolah') }}
            </h2>

            <form action="{{ route('sekolah.store') }}" method="POST" class="bg-white p-6 shadow rounded-lg space-y-4">
                @csrf

                @include('sekolah.form')

                <button type="submit" class="bg-green-500 text-white px-4 py-2 rounded">Simpan</button>
                <a href="{{ route('sekolah.index') }}" class="text-gray-600 ml-2">Batal</a>
            </form>
        </div>
    </div>
@endsection
