<?php

namespace App\Http\Controllers;

use App\Models\Sekolah;
use Illuminate\Http\Request;

class SekolahController extends Controller
{
    // Tampilkan semua data (Web & API)
    public function index()
    {
        $sekolahs = Sekolah::all();

        if (request()->wantsJson()) {
            return response()->json($sekolahs);
        }

        return view('sekolah.index', compact('sekolahs'));
    }

    // Tampilkan form tambah (Web only)
    public function create()
    {
        return view('sekolah.create');
    }

    // Simpan data baru (Web & API)
    public function store(Request $request)
    {
        $validated = $this->validateData($request);

        $sekolah = Sekolah::create($validated);

        if ($request->wantsJson()) {
            return response()->json([
                'message' => 'Data berhasil ditambahkan.',
                'data' => $sekolah
            ], 201);
        }

        // return redirect()->route('sekolah.index')->with('success', 'Data berhasil ditambahkan.');
    }

    // Tampilkan detail sekolah (Web & API)
    public function show(Sekolah $sekolah)
    {
        if (request()->wantsJson()) {
            return response()->json($sekolah);
        }

        return view('sekolah.show', compact('sekolah'));
    }

    // Tampilkan form edit (Web only)
    public function edit(Sekolah $sekolah)
    {
        return view('sekolah.edit', compact('sekolah'));
    }

    // Update data (Web & API)
    public function update(Request $request, Sekolah $sekolah)
    {
        $validated = $this->validateData($request);

        $sekolah->update($validated);

        if ($request->wantsJson()) {
            return response()->json([
                'message' => 'Data berhasil diupdate.',
                'data' => $sekolah
            ]);
        }

        return redirect()->route('sekolah.index')->with('success', 'Data berhasil diupdate.');
    }

    // Hapus data (Web & API)
    public function destroy(Sekolah $sekolah)
    {
        $sekolah->delete();

        if (request()->wantsJson()) {
            return response()->json(['message' => 'Data berhasil dihapus.']);
        }

        return redirect()->route('sekolah.index')->with('success', 'Data berhasil dihapus.');
    }

    // Validator reusable
    private function validateData(Request $request)
    {
        return $request->validate([
            'nama' => 'required|string',
            'alamat' => 'required|string',
            'telepon' => 'required|string',
            'email' => 'nullable|email',
            'jenis_sekolah' => 'required|string',
            'status_sekolah' => 'required|string',
            'akreditasi' => 'required|string',
            'website' => 'nullable|string',
            'latitude' => 'nullable|numeric',
            'longitude' => 'nullable|numeric',
        ]);
    }
}
