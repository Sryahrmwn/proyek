@php
    $isEdit = isset($sekolah);
@endphp

<div>
    <label>Nama:</label>
    <input type="text" name="nama" value="{{ old('nama', $isEdit ? $sekolah->nama : '') }}" class="w-full border p-2 rounded">
</div>

<div>
    <label>Alamat:</label>
    <textarea name="alamat" class="w-full border p-2 rounded">{{ old('alamat', $isEdit ? $sekolah->alamat : '') }}</textarea>
</div>

<div>
    <label>Telepon:</label>
    <input type="text" name="telepon" value="{{ old('telepon', $isEdit ? $sekolah->telepon : '') }}" class="w-full border p-2 rounded">
</div>

<div>
    <label>Email:</label>
    <input type="email" name="email" value="{{ old('email', $isEdit ? $sekolah->email : '') }}" class="w-full border p-2 rounded">
</div>

<div>
    <label>Jenis Sekolah:</label>
    <select name="jenis_sekolah" class="w-full border p-2 rounded">
        <option value="">Pilih Jenis Sekolah</option>
        @foreach (['SD', 'SMP', 'SMA', 'SMK'] as $jenis)
            <option value="{{ $jenis }}" {{ old('jenis_sekolah', $isEdit ? $sekolah->jenis_sekolah : '') == $jenis ? 'selected' : '' }}>{{ $jenis }}</option>
        @endforeach
    </select>
</div>

<div>
    <label>Status Sekolah:</label>
    <select name="status_sekolah" class="w-full border p-2 rounded">
        <option value="">Pilih Status Sekolah</option>
        @foreach (['Negeri', 'Swasta'] as $status)
            <option value="{{ $status }}" {{ old('status_sekolah', $isEdit ? $sekolah->status_sekolah : '') == $status ? 'selected' : '' }}>{{ $status }}</option>
        @endforeach
    </select>
</div>

<div>
    <label>Akreditasi:</label>
    <select name="akreditasi" class="w-full border p-2 rounded">
        <option value="">Pilih Akreditasi</option>
        @foreach (['A', 'B', 'C', 'Tidak Terakreditasi'] as $akreditasi)
            <option value="{{ $akreditasi }}" {{ old('akreditasi', $isEdit ? $sekolah->akreditasi : '') == $akreditasi ? 'selected' : '' }}>{{ $akreditasi }}</option>
        @endforeach
    </select>
</div>

<div>
    <label>Website:</label>
    <input type="text" name="website" value="{{ old('website', $isEdit ? $sekolah->website : '') }}" class="w-full border p-2 rounded">
</div>

<div>
    <label>Latitude:</label>
    <input type="text" name="latitude" value="{{ old('latitude', $isEdit ? $sekolah->latitude : '') }}" class="w-full border p-2 rounded">
</div>

<div>
    <label>Longitude:</label>
    <input type="text" name="longitude" value="{{ old('longitude', $isEdit ? $sekolah->longitude : '') }}" class="w-full border p-2 rounded">
</div>
