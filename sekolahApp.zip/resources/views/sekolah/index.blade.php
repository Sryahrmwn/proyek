@extends('layouts.app')

@section('content')
<div class="container mx-auto px-4 py-6">

<div class="py-0 flex justify-center">
    <div class="border border-gray-400  shadow-sm rounded-lg inline-block">
        <div class="px-6 py-4 text-center text-gray-900 dark:text-gray-100 font-sans text-xl font-semibold tracking-wide">
            {{ __("Data Sekolah") }}
        </div>
    </div>
</div>




    @if(session('success'))
        <div class="bg-green-100 text-green-800 px-4 py-2 rounded mb-4 border border-green-300">
            {{ session('success') }}
        </div>
    @endif

    <div class="mb-4 flex justify-end">
        <a href="{{ route('sekolah.create') }}" class="bg-blue-500 text-white px-4 py-2 rounded">
            + Tambah Sekolah
        </a>
    </div>

    <div class="overflow-x-auto bg-white text-gray-800 rounded-lg shadow border border-gray-200">
        <table class="min-w-full table-auto text-sm">
            <thead class="bg-gray-200 text-gray-700">
                <tr>
                    <th class="p-3 border border-gray-300">Nama</th>
                    <th class="p-3 border border-gray-300">Telepon</th>
                    <th class="p-3 border border-gray-300">Email</th>
                    <th class="p-3 border border-gray-300">Jenis</th>
                    <th class="p-3 border border-gray-300">Status</th>
                    <th class="p-3 border border-gray-300">Akreditasi</th>
                    <th class="p-3 border border-gray-300">Website</th>
                    <th class="p-3 border border-gray-300">Longitude</th>
                    <th class="p-3 border border-gray-300">Latitude</th>
                    <th class="p-3 border border-gray-300">Aksi</th>
                </tr>
            </thead>
            <tbody>
                @forelse($sekolahs as $sekolah)
                    <tr class="border-b border-gray-300 hover:bg-gray-100">
                        <td class="p-3 border border-gray-300">{{ $sekolah->nama }}</td>
                        <td class="p-3 border border-gray-300">{{ $sekolah->telepon }}</td>
                        <td class="p-3 border border-gray-300">{{ $sekolah->email }}</td>
                        <td class="p-3 border border-gray-300">{{ $sekolah->jenis_sekolah }}</td>
                        <td class="p-3 border border-gray-300">{{ $sekolah->status_sekolah }}</td>
                        <td class="p-3 border border-gray-300">{{ $sekolah->akreditasi }}</td>
                        <td class="p-3 border border-gray-300">{{ $sekolah->website }}</td>
                        <td class="p-3 border border-gray-300">{{ $sekolah->longitude }}</td>
                        <td class="p-3 border border-gray-300">{{ $sekolah->latitude }}</td>
                        <td class="p-3 border border-gray-300">
    <div class="flex flex-col space-y-2">
        <a href="{{ route('sekolah.edit', $sekolah) }}">
            <button type="button" class="bg-blue-500 text-white px-3 py-1 rounded hover:bg-yellow-500 w-full">
                Edit
            </button>
        </a>
        <form action="{{ route('sekolah.destroy', $sekolah) }}" method="POST" onsubmit="return confirm('Yakin ingin menghapus?')">
            @csrf
            @method('DELETE')
            <button type="submit" class="bg-red-600 text-white px-3 py-1 rounded hover:bg-red-700 w-full">
                Hapus
            </button>
        </form>
    </div>
</td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="10" class="text-center p-4 text-gray-500">Data sekolah belum tersedia.</td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>
@endsection
